import bezier from "bezier-easing";
import type { DomLyricPlayer } from ".";
import type { LyricLine, LyricWord } from "../../interfaces";
import styles from "../../styles/lyric-player.module.css";
import { chunkAndSplitLyricWords } from "../../utils/lyric-split-words";
import { createMatrix4, matrix4ToCSS, scaleMatrix4 } from "../../utils/matrix";
import { LyricLineBase } from "../base";

interface RealWord extends LyricWord {
	mainElement: HTMLSpanElement;
	subElements: HTMLSpanElement[];
	elementAnimations: Animation[];
	maskAnimations: Animation[];
	width: number;
	height: number;
	padding: number;
	shouldEmphasize: boolean;
	tailFeather?: number;
	tailGlowRestTime?: number;
	clockMask?: { times: number[]; pixels: number[]; index: number; last: number };
}

const ANIMATION_FRAME_QUANTITY = 32;

const norNum = (min: number, max: number) => (x: number) =>
	Math.min(1, Math.max(0, (x - min) / (max - min)));
const EMP_EASING_MID = 0.5;
const beginNum = norNum(0, EMP_EASING_MID);
const endNum = norNum(EMP_EASING_MID, 1);

const bezIn = bezier(0.2, 0.4, 0.58, 1.0);
const bezOut = bezier(0.3, 0.0, 0.58, 1.0);

const makeEmpEasing = (mid: number) => {
	return (x: number) => (x < mid ? bezIn(beginNum(x)) : 1 - bezOut(endNum(x)));
};

function generateFadeGradient(
	width: number,
	padding = 0,
	bright = "rgba(0,0,0,var(--bright-mask-alpha, 1.0))",
	dark = "rgba(0,0,0,var(--dark-mask-alpha, 1.0))",
): [string, number] {
	const totalAspect = 2 + width + padding;
	const widthInTotal = width / totalAspect;
	const leftPos = (1 - widthInTotal) / 2;
	return [
		`linear-gradient(to right,${bright} ${leftPos * 100}%,${dark} ${
			(leftPos + widthInTotal) * 100
		}%)`,
		totalAspect,
	];
}

export class RawLyricLineMouseEvent extends MouseEvent {
	constructor(
		public readonly line: LyricLineEl,
		event: MouseEvent,
	) {
		super(event.type, event);
	}
}

function getScaleFromTransform(transform: string): number {
	const match = transform.match(/matrix\(([^)]+)\)/);
	if (match) {
		const values = match[1].split(", ");
		const scaleX = Number.parseFloat(values[0]);
		const scaleY = Number.parseFloat(values[3]);
		return (scaleX + scaleY) / 2; // Average of scaleX and scaleY
	}
	return 1; // Default scale value if not found
}

type MouseEventMap = {
	[evt in keyof HTMLElementEventMap]: HTMLElementEventMap[evt] extends MouseEvent
		? evt
		: never;
};
type MouseEventTypes = MouseEventMap[keyof MouseEventMap];
type MouseEventListener = (
	this: LyricLineEl,
	ev: RawLyricLineMouseEvent,
) => void;

export class LyricLineEl extends LyricLineBase {
	private element: HTMLElement = document.createElement("div");
	private splittedWords: RealWord[] = [];
	private romanWords: RealWord[] = [];
	private readingSpans: { label: HTMLSpanElement; startTime: number }[] = [];
	private litReadings = 0;
	animatedWords: RealWord[] = [];
	// 由 LyricPlayer 来设置
	lineSize: number[] = [0, 0];

	constructor(
		private lyricPlayer: DomLyricPlayer,
		private lyricLine: LyricLine = {
			words: [],
			translatedLyric: "",
			romanLyric: "",
			startTime: 0,
			endTime: 0,
			isBG: false,
			isDuet: false,
		},
	) {
		super();
		this._prevParentEl = lyricPlayer.rowLayer;
		this.element.setAttribute("class", styles.lyricLine);
		this.element.classList.toggle("anp-background-vocal", !!this.lyricLine.backgroundVocal || this.lyricLine.isBG);
		if (this.lyricLine.isBG) {
			this.element.classList.add(styles.lyricBgLine);
		}
		if (this.lyricLine.isDuet) {
			this.element.classList.add(styles.lyricDuetLine);
		}
		this.element.appendChild(document.createElement("div")); // 歌词行
		this.element.appendChild(document.createElement("div")); // 音译行
		this.element.appendChild(document.createElement("div")); // 翻译行
		const main = this.element.children[0] as HTMLDivElement;
		const trans = this.element.children[2] as HTMLDivElement;
		const roman = this.element.children[1] as HTMLDivElement;
		main.setAttribute("class", styles.lyricMainLine);
		trans.setAttribute("class", styles.lyricSubLine);
		roman.classList.add(styles.lyricSubLine, "anp-roman");
		trans.classList.add("anp-translation");
		this.rebuildStyle();
	}
	private listenersMap = new Map<string, Set<MouseEventListener>>();
	private readonly onMouseEvent = (e: MouseEvent) => {
		const wrapped = new RawLyricLineMouseEvent(this, e);
		for (const listener of this.listenersMap.get(e.type) ?? []) {
			listener.call(this, wrapped);
		}
		if (!this.dispatchEvent(wrapped) || wrapped.defaultPrevented) {
			e.preventDefault();
			e.stopPropagation();
			e.stopImmediatePropagation();
			return false;
		}
	};

	addMouseEventListener(
		type: MouseEventTypes,
		callback: MouseEventListener | null,
		options?: boolean | AddEventListenerOptions | undefined,
	): void {
		if (callback) {
			const listeners = this.listenersMap.get(type) ?? new Set();
			if (listeners.size === 0)
				this.element.addEventListener(type, this.onMouseEvent, options);
			listeners.add(callback);
			this.listenersMap.set(type, listeners);
		}
	}

	removeMouseEventListener(
		type: MouseEventTypes,
		callback: MouseEventListener | null,
		options?: boolean | EventListenerOptions | undefined,
	): void {
		if (callback) {
			const listeners = this.listenersMap.get(type);
			if (listeners) {
				listeners.delete(callback);
				if (listeners.size === 0)
					this.element.removeEventListener(type, this.onMouseEvent, options);
			}
		}
	}

	areWordsOnSameLine(word1: RealWord, word2: RealWord) {
		if (word1?.mainElement && word2?.mainElement) {
			const word1el = word1.mainElement;
			const word2el = word2.mainElement;

			const rect1 = word1el.getBoundingClientRect();
			const rect2 = word2el.getBoundingClientRect();

			// 检查两个单词的顶部距离是否相等（或者差值很小）
			const topDifference = Math.abs(rect1.top - rect2.top);

			// 如果顶部距离相差很小，可以认为它们在同一行上
			return topDifference < 10;
		}

		return true;
	}

	private isEnabled = false;
	private hasContent = false;
	private played = false;

	get motionSettled() {
		const {posX,posY,scale} = this.lineTransforms;
		return posX.idle && posY.idle && scale.idle;
	}

	private ensureContent() {
		if (!this.hasContent) this.rebuildElement();
	}
	private releaseHiddenContent() {
		if (!this.hasContent || this.isEnabled || !this._hide) return;
		this.disposeElements();
		for (const child of this.element.children) child.replaceChildren();
		this.hasContent = this.hasEffects = false;
	}
	hasEffects = false;
	private lastMaskProgress = NaN;
	enable(maskAnimationTime = this.lyricLine.startTime) {
		this.lyricPlayer.movingLines.add(this);
		this.isEnabled = true;
		if (this.lyricPlayer.supportWebkitMaskImage && !this.lyricPlayer.supportMaskImage) this.lyricPlayer.clockMasks.add(this);
		if (!this.hasEffects && !this.lyricPlayer._getIsNonDynamic()) {
			this.rebuildElement(true);
			this.markMaskImageDirty();
		}
		this.element.classList.add(styles.active);
		const main = this.element.children[0] as HTMLDivElement;
		for (const word of this.animatedWords) {
			for (const a of word.elementAnimations) {
				a.currentTime = 0;
				a.playbackRate = 1;
				a.play();
			}
			for (const a of word.maskAnimations) {
				a.currentTime = Math.min(
					this.totalDuration,
					Math.max(0, maskAnimationTime - this.lyricLine.startTime),
				);
				a.playbackRate = 1;
				a.play();
			}
		}
		main.classList.add(styles.active);
	}
	disable() {
		const time = this.lyricPlayer.getCurrentTime();
		this.paintClockMasks(time);
		this.syncReadingGroups(time);
		this.lyricPlayer.clockMasks.delete(this);
		this.lyricPlayer.movingLines.add(this);
		this.isEnabled = false;
		this.element.classList.remove(styles.active);
		const main = this.element.children[0] as HTMLDivElement;
		for (const word of this.animatedWords) {
			for (const a of word.elementAnimations) {
				if (a.id === "anp-tail-glow") {
					a.pause();
					continue;
				}
				if (
					a.id === "float-word" ||
					a.id.includes("emphasize-word-float-only")
				) {
					a.playbackRate = -1;
					a.play();
				}
			}
		}
		main.classList.remove(styles.active);
		this.releaseHiddenContent();
	}
	private lastWord?: RealWord;
	resume() {
		if (!this.isEnabled) return;
		for (const word of this.animatedWords) {
			for (const a of word.elementAnimations) {
				if (
					!this.lastWord ||
					this.animatedWords.indexOf(this.lastWord) <
						this.animatedWords.indexOf(word)
				) {
					a.play();
				}
			}
			for (const a of word.maskAnimations) {
				if (
					!this.lastWord ||
					this.animatedWords.indexOf(this.lastWord) <
						this.animatedWords.indexOf(word)
				) {
					a.play();
				}
			}
		}
	}
	pause() {
		if (!this.isEnabled) return;
		for (const word of this.animatedWords) {
			for (const a of word.elementAnimations) {
				a.pause();
			}
			for (const a of word.maskAnimations) {
				a.pause();
			}
		}
	}
	setMaskAnimationState(maskAnimationTime = 0) {
		const t = maskAnimationTime - this.lyricLine.startTime;
		for (const word of this.animatedWords) {
			for (const a of word.maskAnimations) {
				a.currentTime = Math.min(this.totalDuration, Math.max(0, t));
				a.playbackRate = 1;
				if (t >= 0 && t < this.totalDuration) a.play();
				else a.pause();
			}
		}
	}
	prepareMeasure() {
		this.ensureContent();
		if (!this._hide) return;
		this._prevParentEl?.appendChild(this.element);
		this.element.style.display = "";
		this.element.style.visibility = "hidden";
	}
	readSize(): [number, number] {
		const size: [number, number] = [this.element.clientWidth, this.element.clientHeight];
		this.lineSize = size;
		return size;
	}
	finishMeasure() {
		if (!this._hide) return;
		this.element.remove();
		this.element.style.display = "none";
		this.element.style.visibility = "";
		this.releaseHiddenContent();
	}
	measureSize(): [number, number] {
		this.prepareMeasure();
		try { return this.readSize(); }
		finally { this.finishMeasure(); }
	}
	getLine() {
		return this.lyricLine;
	}
	private _hide = true;
	private _prevParentEl: HTMLElement | null = null;
	private styleHidden?: boolean;
	private lastX = NaN;
	private lastY = NaN;
	private lastScale = NaN;
	private lastTransform = "";
	private lastBlur = NaN;
	private lastDelay = "";
	show() {
		this.ensureContent();
		this._hide = false;
		if (this._prevParentEl) {
			this._prevParentEl.appendChild(this.element);
			this._prevParentEl = null;
		}
		this.rebuildStyle();
	}
	hide() {
		this._hide = true;
		if (this.element.parentElement) {
			this._prevParentEl = this.element.parentElement;
			this.element.remove();
		}
		this.rebuildStyle();
	}
	resetUnstartedInk(time: number) {
		this.syncReadingGroups(time);
		if (this.isEnabled || !this.hasEffects || time >= this.lyricLine.startTime) return;
		if (this._hide) this.releaseHiddenContent();
		else this.rebuildElement();
	}
	updateReadingState(time: number) {
		const played = time >= this.lyricLine.endTime;
		if (played === this.played) return;
		this.played = played;
		this.element.classList.toggle("anp-played-row", played);
	}
	placeInBrowse(top: number, scale: number, opacity: number) {
		this.updateReadingState(this.lyricPlayer.getCurrentTime());
		this.lineTransforms.posY.setPosition(top);
		this.lineTransforms.scale.setPosition(scale);
		this.setMainOpacity(opacity);
		this.show();
		this.updateMaskAlpha(scale / 100);
	}
	leaveBrowseWindow() {
		this.hide();
		this.releaseHiddenContent();
	}
	refreshBrowseInk() {
		if (!this._hide && this.maskImageDirty) this.updateMaskImage();
	}

	private setMainOpacity(opacity: number) {
		const style = (this.element.children[0] as HTMLElement).style;
		const value = String(opacity);
		if (style.opacity !== value) style.opacity = value;
	}

	private rebuildStyle() {
		const style = this.element.style;
		if (this.styleHidden !== this._hide) {
			style.display = this._hide ? "none" : "";
			this.styleHidden = this._hide;
			if (this._hide) {
				style.transform = "translate(0,-10000px)";
				this.lastX = NaN;
				this.lastTransform = "";
			}
		}
		if (this._hide) return;

		const x = this.lineTransforms.posX.getCurrentPosition();
		const y = this.lineTransforms.posY.getCurrentPosition();
		const scale = this.lineTransforms.scale.getCurrentPosition() / 100;
		if (x !== this.lastX || y !== this.lastY || scale !== this.lastScale) {
			this.lastX = x;
			this.lastY = y;
			this.lastScale = scale;
			const transform = "translate(" + x.toFixed(1) + "px," + y.toFixed(1) + "px) scale(" + scale.toFixed(4) + ")";
			if (transform !== this.lastTransform) {
				style.transform = transform;
				this.lastTransform = transform;
			}
		}
		const blur = Math.min(32, this.blur);
		if (blur !== this.lastBlur) {
			style.filter = "blur(" + blur + "px)";
			this.lastBlur = blur;
		}
		const delay = !this.lyricPlayer.getEnableSpring() && this.isInSight ? this.delay + "ms" : "";
		if (delay !== this.lastDelay) {
			style.transitionDelay = delay;
			this.lastDelay = delay;
		}
	}
	rebuildElement(withEffects = false) {
		this.hasContent = true;
		this.disposeElements();
		this.hasEffects = withEffects;
		this.element.classList.toggle("anp-reading-row", !withEffects && !this.lyricPlayer._getIsNonDynamic());
		const main = this.element.children[0] as HTMLDivElement;
		const trans = this.element.children[2] as HTMLDivElement;
		const roman = this.element.children[1] as HTMLDivElement;
		const groups = this.lyricLine.readingGroups;
		main.classList.toggle("anp-grouped-readings", !!groups?.length);
		main.replaceChildren();
		if (groups?.length) {
			roman.replaceChildren();
			roman.classList.remove("anp-roman-timed");
			for (const group of groups) {
				const unit = document.createElement("span");
				const base = document.createElement("span");
				const label = document.createElement("span");
				unit.className = "anp-reading-group";
				base.className = "anp-reading-base";
				label.className = "anp-reading-caption";
				if (group.words) this.buildWords(base, group.words, withEffects);
				else base.textContent = group.text ?? "";
				label.textContent = group.roman;
				unit.append(base, label);
				main.append(unit);
				if (withEffects && group.endTime != null && group.endTime > group.startTime) {
					label.classList.add("anp-reading-sweep");
					this.romanWords.push({
						word: group.roman,
						startTime: group.startTime,
						endTime: group.endTime,
						mainElement: label,
						subElements: [],
						maskAnimations: [],
						elementAnimations: [],
						shouldEmphasize: false,
						width: 0,
						height: 0,
						padding: 0
					});
				} else {
					this.readingSpans.push({ label, startTime: group.startTime });
				}
			}
			this.syncReadingGroups(this.lyricPlayer.getCurrentTime());
		} else {
			this.buildRoman(roman);
			if (this.lyricPlayer._getIsNonDynamic()) main.innerText = this.lyricLine.words.map((word) => word.word).join("");
			else this.buildWords(main, this.lyricLine.words, withEffects);
		}
		trans.innerText = this.lyricLine.translatedLyric;
		if (withEffects) this.attachTailGlow();
		this.animatedWords = this.splittedWords.concat(this.romanWords);
	}
	private buildWords(main: HTMLElement, words: LyricWord[], withEffects: boolean) {
		const chunkedWords = chunkAndSplitLyricWords(words);
		// A gap belongs between word boxes in both the reading and active layouts.
		const appendGap = () => {
			if (main.lastChild?.nodeType !== Node.TEXT_NODE) main.append(" ");
		};
		for (const chunk of chunkedWords) {
			if (Array.isArray(chunk)) {
				// 多个没有空格的单词组合成的一个单词数组
				if (chunk.length === 0) continue;
				const merged = chunk.reduce(
					(a, b) => {
						a.endTime = Math.max(a.endTime, b.endTime);
						a.startTime = Math.min(a.startTime, b.startTime);
						a.word += b.word;
						return a;
					},
					{
						word: "",
						startTime: Number.POSITIVE_INFINITY,
						endTime: Number.NEGATIVE_INFINITY,
					},
				);
				const emp = chunk
					.map((word) => LyricLineBase.shouldEmphasize(word))
					.reduce((a, b) => a || b, LyricLineBase.shouldEmphasize(merged));
				const wrapperWordEl = document.createElement("span");
				wrapperWordEl.classList.add(styles.emphasizeWrapper);
				const characterElements: HTMLElement[] = [];
				for (const word of chunk) {
					const mainWordEl = document.createElement("span");
					// const mainWordFloatAnimation = this.initFloatAnimation(
					// 	merged,
					// 	mainWordEl,
					// );
					if (emp) {
						mainWordEl.classList.add(styles.emphasize);
						const charEls: HTMLSpanElement[] = [];
						for (const char of word.word.trim().split("")) {
							const charEl = document.createElement("span");
							charEl.innerText = char;
							charEls.push(charEl);
							characterElements.push(charEl);
							mainWordEl.appendChild(charEl);
						}
						const realWord: RealWord = {
							...word,
							mainElement: mainWordEl,
							subElements: charEls,
							elementAnimations: this.hasEffects ? [this.initFloatAnimation(word, mainWordEl)] : [],
							maskAnimations: [],
							width: 0,
							height: 0,
							padding: 0,
							shouldEmphasize: emp,
						};
						this.splittedWords.push(realWord);
					} else {
						mainWordEl.classList.add("anp-descender-space");
						mainWordEl.innerText = word.word.trim();
						this.splittedWords.push({
							...word,
							mainElement: mainWordEl,
							subElements: [],
							elementAnimations: this.hasEffects ? [this.initFloatAnimation(word, mainWordEl)] : [],
							maskAnimations: [],
							width: 0,
							height: 0,
							padding: 0,
							shouldEmphasize: emp,
						});
					}
					wrapperWordEl.appendChild(mainWordEl);
				}
				if (emp && withEffects) {
					this.splittedWords[
						this.splittedWords.length - 1
					].elementAnimations.push(
						...this.initEmphasizeAnimation(
							merged,
							characterElements,
							merged.endTime - merged.startTime,
							merged.startTime - this.lyricLine.startTime,
						),
					);
				}

				if (merged.word.trimStart() !== merged.word) {
					appendGap();
				}
				main.appendChild(wrapperWordEl);
				if (merged.word.trimEnd() !== merged.word) {
					appendGap();
				}
			} else if (chunk.word.trim().length === 0) {
				// 纯空格
				appendGap();
			} else {
				// 单个单词
				const emp = LyricLineBase.shouldEmphasize(chunk);
				const mainWordEl = document.createElement("span");
				const realWord: RealWord = {
					...chunk,
					mainElement: mainWordEl,
					subElements: [],
					elementAnimations: this.hasEffects ? [this.initFloatAnimation(chunk, mainWordEl)] : [],
					maskAnimations: [],
					width: 0,
					height: 0,
					padding: 0,
					shouldEmphasize: emp,
				};
				if (emp) {
					mainWordEl.classList.add(styles.emphasize);
					const charEls: HTMLSpanElement[] = [];
					for (const char of chunk.word.trim().split("")) {
						const charEl = document.createElement("span");
						charEl.innerText = char;
						charEls.push(charEl);
						mainWordEl.appendChild(charEl);
					}
					realWord.subElements = charEls;
					if (withEffects) {
						const duration = Math.abs(realWord.endTime - realWord.startTime);
						realWord.elementAnimations.push(
							...this.initEmphasizeAnimation(
								chunk,
								charEls,
								duration,
								realWord.startTime - this.lyricLine.startTime,
							),
						);
						// realWord.elementAnimations = this.initEmphasizeAnimation(realWord);
					}
				} else {
					mainWordEl.innerText = chunk.word.trim();
				}
				if (chunk.word.trimStart() !== chunk.word) {
					appendGap();
				}
				main.appendChild(mainWordEl);
				if (chunk.word.trimEnd() !== chunk.word) {
					appendGap();
				}
				this.splittedWords.push(realWord);
			}
		}
	}
	syncReadingGroups(time: number) {
		const readings = this.readingSpans;
		while (this.litReadings > 0 && readings[this.litReadings - 1].startTime > time) {
			readings[--this.litReadings].label.classList.remove("anp-reading-lit");
		}
		while (this.litReadings < readings.length && readings[this.litReadings].startTime <= time) {
			readings[this.litReadings++].label.classList.add("anp-reading-lit");
		}
	}
	// Romanization has its own beat boundaries, even when both lines wrap.
	private buildRoman(container: HTMLElement) {
		container.replaceChildren();
		const timed = this.lyricLine.romanWords || [];
		container.classList.toggle("anp-roman-timed", timed.length > 0);
		if (!timed.length) {
			container.textContent = this.lyricLine.romanLyric;
			return;
		}
		for (const part of timed) {
			const el = document.createElement("span");
			const text = part.word.trim();
			if (/^\s/.test(part.word)) container.append(" ");
			if (text) {
				el.textContent = text;
				container.append(el);
				this.romanWords.push({
					...part, mainElement: el, subElements: [], maskAnimations: [],
					elementAnimations: this.hasEffects ? [this.initFloatAnimation(part, el)] : [], shouldEmphasize: false,
					width: 0, height: 0, padding: 0,
				});
			}
			if (text && /\s$/.test(part.word)) container.append(" ");
		}
	}

	private attachTailGlow() {
		if (!this.lyricLine.hasWordTiming) return;
		const word = [...this.splittedWords].reverse().find(w => /[\p{L}\p{N}]/u.test(w.word));
		if (!word) return;
		const duration = word.endTime - word.startTime;
		if (duration < 380) return;
		const wordDuration = Math.max(0, duration);
		const handoff = this.lyricLine.tailHandoffTime ?? this.lyricLine.endTime;
		const tailGap = Math.max(0, handoff - word.endTime);
		const delay = word.startTime - this.lyricLine.startTime;
		const totalDuration = wordDuration + tailGap + 250;
		word.tailGlowRestTime = delay + wordDuration + tailGap;
		// Only the last sung CJK glyph gets the halo, including before punctuation.
		const walker = document.createTreeWalker(word.mainElement, NodeFilter.SHOW_TEXT);
		let last: Text | undefined;
		for (let node = walker.nextNode(); node; node = walker.nextNode()) {
			if (/[\p{L}\p{N}]/u.test(node.textContent || "")) last = node as Text;
		}
		const match = last?.data.match(/([\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}\p{Script=Hangul}ー]\p{M}*)[\p{P}\s]*$/u);
		if (!last || !match || match.index === undefined) return;
		const glyph = last.splitText(match.index);
		glyph.splitText(match[1].length);
		const ink = document.createElement("span");
		ink.className = "anp-tail-ink";
		glyph.replaceWith(ink);
		ink.append(glyph);
		// A grouped word can store this tail's old emphasis on another segment.
		for (const part of this.splittedWords) {
			part.elementAnimations = part.elementAnimations.filter((effect) => {
				const target = (effect.effect as KeyframeEffect | null)?.target ?? null;
				if (!word.mainElement.contains(target)) return true;
				effect.cancel();
				return false;
			});
		}
		word.elementAnimations.push(this.initFloatAnimation(word, ink, 0.045));
		const isLightTail = wordDuration < 650;
		const strength = isLightTail ? 0.5 * Math.min(1, wordDuration / 650) : Math.min(1, wordDuration / 1000);
		word.tailFeather = (isLightTail ? 0.15 : 0.22) * strength;
		const decoration = "var(--anp-word-decoration, 0 0 transparent)";
		const off = "0 0 0em transparent, 0 0 0em transparent, " + decoration;
		const shadow = (alpha: number) => `0 0 .075em rgba(255,255,255,${0.72 * alpha}), 0 0 .20em rgba(255,255,255,${0.54 * alpha}), ${decoration}`;
		const peak = shadow(strength);
		const tPeak = wordDuration * 0.35 / totalDuration;
		const tHold = wordDuration / totalDuration;
		const animation = ink.animate([
			{ textShadow: off, offset: 0, easing: "ease-out" },
			{ textShadow: peak, offset: tPeak },
			{ textShadow: peak, offset: tHold, easing: "ease-out" },
			...(tailGap > 0 ? [{
				textShadow: shadow(strength * 0.12),
				offset: (wordDuration + tailGap) / totalDuration,
				easing: "ease-out"
			}] : []),
			{ textShadow: off, offset: 1 }
		], {
			id: "anp-tail-glow",
			duration: totalDuration,
			delay,
			fill: "both",
			easing: "linear"
		});
		animation.pause();
		word.elementAnimations.push(animation);
	}

	private initFloatAnimation(word: LyricWord, wordEl: HTMLElement, up = this.lyricLine.isBG ? 0.1 : 0.05) {
		const delay = word.startTime - this.lyricLine.startTime;
		const duration = Math.max(1000, word.endTime - word.startTime);
		const a = wordEl.animate(
			[
				{
					transform: "translateY(0px)",
				},
				{
					transform: `translateY(${-up}em)`,
				},
			],
			{
				duration: Number.isFinite(duration) ? duration : 0,
				delay: Number.isFinite(delay) ? delay : 0,
				id: "float-word",
				composite: "add",
				fill: "both",
				easing: "ease-out",
			},
		);
		a.pause();
		return a;
	}
	// 按照原 Apple Music 参考，强调效果只应用缩放、轻微左右位移和辉光效果，原主要的悬浮位移效果不变
	// 为了避免产生锯齿抖动感，使用 matrix3d 来实现缩放和位移
	private initEmphasizeAnimation(
		word: LyricWord,
		characterElements: HTMLElement[],
		duration: number,
		delay: number,
	): Animation[] {
		const de = Math.max(0, delay);
		let du = Math.max(1000, duration);

		let result: Animation[] = [];

		let amount = du / 2000;
		amount = amount > 1 ? Math.sqrt(amount) : amount ** 3;
		let blur = du / 3000;
		blur = blur > 1 ? Math.sqrt(blur) : blur ** 3;
		amount *= 0.6;
		blur *= 0.5;
		if (
			this.lyricLine.words.length > 0 &&
			word.word.includes(
				this.lyricLine.words[this.lyricLine.words.length - 1].word,
			)
		) {
			amount *= 1.6;
			blur *= 1.5;
			du *= 1.2;
		}
		amount = Math.min(1.2, amount);
		blur = Math.min(0.8, blur);

		const animateDu = Number.isFinite(du) ? du : 0;
		const empEasing = makeEmpEasing(EMP_EASING_MID);
		const steadyLift = this.steadyVocalLift;

		result = characterElements.flatMap((el, i, arr) => {
			const wordDe = de + (du / 2.5 / arr.length) * i;
			const result: Animation[] = [];

			const frames: Keyframe[] = new Array(ANIMATION_FRAME_QUANTITY)
				.fill(0)
				.map((_, j) => {
					const x = (j + 1) / ANIMATION_FRAME_QUANTITY;
					const transX = empEasing(x);
					const glowLevel = empEasing(x) * blur;

					const mat = scaleMatrix4(createMatrix4(), 1 + transX * 0.1 * amount);
					const offsetX = -transX * 0.03 * amount * (arr.length / 2 - i);
					const offsetY = steadyLift ? 0 : -transX * 0.025 * amount;

					return {
						offset: x,
						transform: `${matrix4ToCSS(
							mat,
							4,
						)} translate(${offsetX}em, ${offsetY}em)`,
						textShadow: `0 0 ${Math.min(
							0.3,
							blur * 0.3,
						)}em rgba(255, 255, 255, ${glowLevel}), var(--anp-word-decoration, 0 0 transparent)`,
					};
				});

			const glow = el.animate(frames, {
				duration: animateDu,
				delay: Number.isFinite(wordDe) ? wordDe : 0,
				id: `emphasize-word-${el.innerText}-${i}`,
				iterations: 1,
				composite: "replace",
				fill: "both",
			});
			glow.onfinish = () => {
				glow.pause();
			};
			glow.pause();
			result.push(glow);
			if (steadyLift) {
				const startTime = this.lyricLine.startTime + wordDe - 400;
				result.push(this.initFloatAnimation(
					{ ...word, startTime, endTime: startTime + animateDu * 0.7 },
					el
				));
				return result;
			}

			const floatFrame: Keyframe[] = new Array(ANIMATION_FRAME_QUANTITY)
				.fill(0)
				.map((_, j) => {
					const x = (j + 1) / ANIMATION_FRAME_QUANTITY;
					let y = Math.sin(x * Math.PI);
					// y = x < 0.5 ? y : Math.max(y, 1.0);
					if (this.lyricLine.isBG) {
						y *= 2;
					}

					return {
						offset: x,
						transform: `translateY(${-y * 0.05}em)`,
					};
				});
			const float = el.animate(floatFrame, {
				duration: animateDu * 1.4,
				delay: Number.isFinite(wordDe) ? wordDe - 400 : 0,
				id: "emphasize-word-float",
				iterations: 1,
				composite: "add",
				fill: "both",
			});
			float.onfinish = () => {
				float.pause();
			};
			float.pause();
			result.push(float);

			return result;
		});

		return result;
	}

	get steadyVocalLift() {
		const { isDuet, isBG, backgroundVocal, hasWordTiming, words } = this.lyricLine;
		return isDuet || isBG || backgroundVocal || (!hasWordTiming && words.length === 1);
	}
	private get totalDuration() {
		return this.lyricLine.endTime - this.lyricLine.startTime;
	}
	private maskImageDirty = false;
	markMaskImageDirty() {
		this.lyricPlayer.movingLines.add(this);
		this.maskImageDirty = this.hasEffects;
	}

	private updateMaskImage() {
		// Called for a connected, visible row. Read all glyph sizes before writing
		// any masks, so wheel input never measures offscreen rows or retains waiters.
		this.maskImageDirty = false;
		for (const word of this.animatedWords) {
			const el = word.mainElement;
			const style = getComputedStyle(el);
			word.padding = parseFloat(style.paddingLeft) || 0;
			word.width = el.clientWidth - 2 * word.padding;
			// The extra bottom padding is paint space, so it must not widen the horizontal feather.
			let height = el.clientHeight;
			if (el.classList.contains("anp-descender-space")) {
				const boxHeight = parseFloat(style.height);
				const inset = style.boxSizing === "border-box" ? parseFloat(style.paddingBottom) || 0 : 0;
				if (Number.isFinite(boxHeight)) height = Math.round(boxHeight - inset);
			}
			word.height = height - 2 * word.padding;
		}
		if (this.lyricPlayer.supportMaskImage || this.lyricPlayer.supportWebkitMaskImage) {
			this.generateWebAnimationBasedMaskImage(this.splittedWords);
			if (this.lyricLine.readingGroups?.length) {
				for (const caption of this.romanWords) this.generateWebAnimationBasedMaskImage([caption]);
			} else {
				this.generateWebAnimationBasedMaskImage(this.romanWords);
			}
		} else {
			this.generateCalcBasedMaskImage();
		}
		if (this.isEnabled) {
			this.setMaskAnimationState(this.lyricPlayer.getCurrentTime());
			this.paintClockMasks(this.lyricPlayer.getCurrentTime());
		}
	}
	private generateCalcBasedMaskImage() {
		for (const word of this.animatedWords) {
			const wordEl = word.mainElement;
			if (wordEl) {
				word.width = wordEl.clientWidth;
				word.height += 2 * word.padding;
				const fadeWidth = word.height * (this.lyricPlayer.getWordFadeWidth() + (word.tailFeather || 0));
				const [maskImage, totalAspect] = generateFadeGradient(
					fadeWidth / word.width,
				);
				const totalAspectStr = `${totalAspect * 100}% 100%`;
				if (this.lyricPlayer.supportMaskImage) {
					wordEl.style.maskImage = maskImage;
					wordEl.style.maskRepeat = "no-repeat";
					wordEl.style.maskOrigin = "left";
					wordEl.style.maskSize = totalAspectStr;
				} else {
					wordEl.style.webkitMaskImage = maskImage;
					wordEl.style.webkitMaskRepeat = "no-repeat";
					wordEl.style.webkitMaskOrigin = "left";
					wordEl.style.webkitMaskSize = totalAspectStr;
				}
				const w = word.width + fadeWidth;
				const maskPos = `clamp(${-w}px,calc(${-w}px + (var(--amll-player-time) - ${
					word.startTime
				})*${
					w / Math.abs(word.endTime - word.startTime)
				}px),0px) 0px, left top`;
				wordEl.style.maskPosition = maskPos;
				wordEl.style.webkitMaskPosition = maskPos;
			}
		}
	}
	// CEF 91 animates registered custom properties on the style engine. Only
	// write a prefixed mask position when its actual gradient edge changes.
	paintClockMasks(time: number) {
		if (this._hide) return;
		const elapsed = time - this.lyricLine.startTime;
		for (const word of this.animatedWords) {
			const mask = word.clockMask;
			if (!mask) continue;
			const { times, pixels } = mask;
			let i = mask.index;
			while (i > 0 && elapsed < times[i]) i--;
			while (i + 1 < times.length && elapsed >= times[i + 1]) i++;
			mask.index = i;
			let x = pixels[i];
			if (elapsed > times[i] && i + 1 < times.length) {
				x += (pixels[i + 1] - x) * (elapsed - times[i]) / (times[i + 1] - times[i]);
			}
			const pixel = Math.round(x * 1000) / 1000;
			if (pixel !== mask.last) {
				mask.last = pixel;
				word.mainElement.style.webkitMaskPosition = pixel + "px 0px";
			}
		}
	}
	private generateWebAnimationBasedMaskImage(track: RealWord[]) {
		// 因为歌词行有可能比行内单词的结束时间早，有可能导致过渡动画提早停止出现瑕疵
		// 所以要以单词的结束时间为准
		const totalFadeDuration =
			Math.max(
				track.reduce((pv, w) => Math.max(w.endTime, pv), 0),
				this.lyricLine.endTime,
			) - this.lyricLine.startTime;
		let precedingWidth = 0;
		track.forEach((word, i) => {
			const prefixWidth = precedingWidth;
			precedingWidth += word.width;
			const wordEl = word.mainElement;
			if (wordEl && word.width > 0 && word.height > 0) {
				const fadeWidth = word.height * (this.lyricPlayer.getWordFadeWidth() + (word.tailFeather || 0));
				const [maskImage, totalAspect] = generateFadeGradient(
					fadeWidth / (word.width + word.padding * 2),
				);
				const totalAspectStr = `${totalAspect * 100}% 100%`;
				if (this.lyricPlayer.supportMaskImage) {
					wordEl.style.maskImage = maskImage;
					wordEl.style.maskRepeat = "no-repeat";
					wordEl.style.maskOrigin = "left";
					wordEl.style.maskSize = totalAspectStr;
				} else {
					wordEl.style.webkitMaskImage = maskImage;
					wordEl.style.webkitMaskRepeat = "no-repeat";
					wordEl.style.webkitMaskOrigin = "left";
					wordEl.style.webkitMaskSize = totalAspectStr;
				}
				// 为了尽可能将渐变动画在相连的每个单词间近似衔接起来
				// 要综合每个单词的效果时间和间隙生成动画帧数组
				const widthBeforeSelf =
					prefixWidth +
					(track[0] ? fadeWidth : 0);
				const minOffset = -(word.width + word.padding * 2 + fadeWidth);
				const clampOffset = (x: number) => Math.max(minOffset, Math.min(0, x));
				let curPos = -widthBeforeSelf - word.width - word.padding - fadeWidth;
				let timeOffset = 0;
				const frames: Keyframe[] = [];
				const nativeMask = this.lyricPlayer.supportMaskImage;
				const maskPosition = nativeMask ? "maskPosition" : "--anp-extspotify-mask-x";
				
				let lastPos = curPos;
				let lastTime = 0;
				const pushFrame = () => {
					// 此处如果添加过渡函数，会导致单词时序不准确，所以不添加
					// const easing = "cubic-bezier(.33,.12,.83,.9)";
					const moveOffset = curPos - lastPos;
					const time = Math.max(0, Math.min(1, timeOffset));
					const duration = time - lastTime;
					const d = Math.abs(duration / moveOffset);
					// 因为有可能会和之前的动画有边界
					if (curPos > minOffset && lastPos < minOffset) {
						const staticTime = Math.abs(lastPos - minOffset) * d;
						const value = `${clampOffset(lastPos)}px 0`;
						const frame: Keyframe = {
							offset: lastTime + staticTime,
							[maskPosition]: nativeMask ? value : value.split(" ")[0],
						};
						frames.push(frame);
					}
					if (curPos > 0 && lastPos < 0) {
						const staticTime = Math.abs(lastPos) * d;
						const value = `${clampOffset(curPos)}px 0`;
						const frame: Keyframe = {
							offset: lastTime + staticTime,
							[maskPosition]: nativeMask ? value : value.split(" ")[0],
						};
						frames.push(frame);
					}
					const value = `${clampOffset(curPos)}px 0`;
					const frame: Keyframe = {
						offset: time,
						[maskPosition]: nativeMask ? value : value.split(" ")[0],
					};
					frames.push(frame);
					lastPos = curPos;
					lastTime = time;
				};
				pushFrame();
				let lastTimeStamp = 0;
				track.forEach((otherWord, j) => {
					// 停顿
					{
						const curTimeStamp = otherWord.startTime - this.lyricLine.startTime;
						const staticDuration = curTimeStamp - lastTimeStamp;
						timeOffset += staticDuration / totalFadeDuration;
						if (staticDuration > 0) pushFrame();
						lastTimeStamp = curTimeStamp;
					}
					// 移动
					{
						const fadeDuration = otherWord.endTime - otherWord.startTime;
						timeOffset += fadeDuration / totalFadeDuration;
						curPos += otherWord.width;
						if (j === 0) {
							curPos += fadeWidth * 1.5;
						}
						if (j === track.length - 1) {
							curPos += fadeWidth * 0.5 + (word.tailFeather ? fadeWidth * 0.5 : 0);
						}
						if (fadeDuration > 0) pushFrame();
						lastTimeStamp += fadeDuration;
					}
				});
				for (const a of word.maskAnimations) {
					a.cancel();
				}
				if (!nativeMask && frames.length && totalFadeDuration > 0 &&
					frames.every((f,k) => Number.isFinite(f.offset) && (!k || Number(f.offset) >= Number(frames[k-1].offset)))) {
					const times: number[] = [], pixels: number[] = [];
					for (const frame of frames) {
						const x = parseFloat(String(frame[maskPosition]));
						const ms = Number(frame.offset) * totalFadeDuration, n = pixels.length;
						if (n >= 2 && x === pixels[n-1] && x === pixels[n-2]) times[n-1] = ms;
						else { times.push(ms); pixels.push(x); }
					}
					if (times[times.length-1] < totalFadeDuration) { times.push(totalFadeDuration); pixels.push(0); }
					word.clockMask = {times, pixels, index: 0, last: NaN};
					word.maskAnimations = [];
					return;
				}
				if (!nativeMask) wordEl.style.webkitMaskPosition = "var(--anp-extspotify-mask-x) 0px";
				try {
					// TODO: 如果此处动画帧计算出错，需要一个后备方案
					// 此处如果添加过渡函数，会导致单词时序不准确，所以不添加
					// Keep the same piecewise-linear sweep, but let WAAPI fill the
					// constant lead-in/tail instead of sampling the whole line for every glyph.
					let first = 0, last = frames.length - 1;
					while (first + 1 < last && frames[first][maskPosition] === frames[first + 1][maskPosition]) first++;
					const explicitEnd = frames[last].offset === 1;
					while (explicitEnd && last > first + 1 && frames[last][maskPosition] === frames[last - 1][maskPosition]) last--;
					const start = Number(frames[first].offset);
					const end = explicitEnd ? Number(frames[last].offset) : 1;
					const span = end - start;
					const compact = span > 0 ? frames.slice(first, last + 1) : frames;
					if (span > 0) {
						for (const frame of compact) frame.offset = (Number(frame.offset) - start) / span;
					}
					const ani = wordEl.animate(compact, {
						delay: span > 0 ? start * totalFadeDuration : 0,
						duration: ((span > 0 ? span : 1) * totalFadeDuration) || 1,
						id: `fade-word-${word.word}-${i}`,
						fill: "both",
					});
					ani.pause();
					word.maskAnimations = [ani];
				} catch (err) {
					console.warn("应用渐变动画发生错误", frames, totalFadeDuration, err);
				}
			}
		});
	}
	getElement() {
		return this.element;
	}
	override setTransform(
		left: number = this.left,
		top: number = this.top,
		scale: number = this.scale,
		opacity = 1,
		blur = 0,
		force = false,
		delay = 0,
	) {
		this.lyricPlayer.movingLines.add(this);
		super.setTransform(left, top, scale, opacity, blur, force, delay);
		const beforeInSight = this.isInSight;
		const enableSpring = this.lyricPlayer.getEnableSpring();
		this.left = left;
		this.top = top;
		this.scale = scale;
		this.delay = (delay * 1000) | 0;
		this.setMainOpacity(opacity);
		if (force || !enableSpring) {
			this.blur = Math.min(32, blur);
			const disableTransition = force && !this.lyricPlayer.isManualScrolling && !this._hide;
			if (disableTransition) this.element.classList.add(styles.tmpDisableTransition);
			// this.lineWebAnimationTransforms.posX.setTargetPosition(left);
			// this.lineWebAnimationTransforms.posY.setTargetPosition(top);
			// this.lineWebAnimationTransforms.scale.setTargetPosition(scale);
			this.lineTransforms.posX.setPosition(left);
			this.lineTransforms.posY.setPosition(top);
			this.lineTransforms.scale.setPosition(scale);
			if (!enableSpring) {
				const afterInSight = this.isInSight;
				if (beforeInSight || afterInSight) {
					this.show();
				} else {
					this.hide();
				}
			} else this.rebuildStyle();
			if (disableTransition)
				requestAnimationFrame(() => {
					this.element.classList.remove(styles.tmpDisableTransition);
				});
		} else {
			// this.lineWebAnimationTransforms.posX.stop();
			// this.lineWebAnimationTransforms.posY.stop();
			// this.lineWebAnimationTransforms.scale.stop();
			this.lineTransforms.posX.setTargetPosition(left, delay);
			this.lineTransforms.posY.setTargetPosition(top, delay);
			this.lineTransforms.scale.setTargetPosition(scale);

		}
	}
	update(delta = 0) {
		if (this.lyricPlayer.getEnableSpring()) {
			this.lineTransforms.posX.update(delta);
			this.lineTransforms.posY.update(delta);
			this.lineTransforms.scale.update(delta);
		}
		if (this.isInSight) {
			this.show();
			if (this.maskImageDirty) {
				this.updateMaskImage();
			}
		} else {
			this.hide();
		}
		if (this._hide) {
			this.releaseHiddenContent();
			return;
		}
		const scale = this.lyricPlayer.getEnableSpring() ? this.lineTransforms.scale.getCurrentPosition() / 100 :
			getScaleFromTransform(getComputedStyle(this.element).transform);
		this.updateMaskAlpha(scale);
	}
	private updateMaskAlpha(scale: number) {
		const progress = Math.max(0, Math.min(1, (scale - .97) / .03));
		if (progress === this.lastMaskProgress) return;
		this.lastMaskProgress = progress;
		this.element.style.setProperty("--bright-mask-alpha", String(.2 + progress * .8));
		this.element.style.setProperty("--dark-mask-alpha", String(.2 + progress * .2));
	}

	_getDebugTargetPos(): string {
		return `[位移: ${this.left}, ${this.top}; 缩放: ${this.scale}; 延时: ${this.delay}]`;
	}

	get isInSight() {
		const l = this.lineTransforms.posX.getCurrentPosition();
		const t = this.lineTransforms.posY.getCurrentPosition();
		const w = this.lineSize[0];
		const h = this.lineSize[1];
		const r = l + w;
		const b = t + h;
		const pr = this.lyricPlayer.size[0];
		const pb = this.lyricPlayer.size[1];
		return !(l > pr + w || r < -w || t > pb + h || b < -h);
	}
	private disposeElements() {
		for (const realWord of this.animatedWords) {
			for (const a of realWord.elementAnimations) {
				a.cancel();
			}
			for (const a of realWord.maskAnimations) {
				a.cancel();
			}
			for (const sub of realWord.subElements) {
				sub.remove();
				sub.parentNode?.removeChild(sub);
			}
			realWord.elementAnimations = [];
			realWord.maskAnimations = [];
			realWord.subElements = [];
			realWord.mainElement.remove();
			realWord.mainElement.parentNode?.removeChild(realWord.mainElement);
		}
		this.splittedWords = [];
		this.romanWords = [];
		this.readingSpans = [];
		this.litReadings = 0;
		this.animatedWords = [];
	}
	override dispose(): void {
		this.lyricPlayer.clockMasks.delete(this);
		this.isEnabled = false;
		this._prevParentEl = null;
		this.disposeElements();
		this.element.remove();
	}
}
