/**
 * @fileoverview
 * 一个播放歌词的组件
 * @author SteveXMH
 */

import type { LyricLine } from "../../interfaces";
import "../../styles/index.css";
import styles from "../../styles/lyric-player.module.css";
import { BrowseColumn, firstIndex, type BrowseRow } from "./browse-column";
import { LyricPlayerBase } from "../base";
import { LyricLineEl, type RawLyricLineMouseEvent } from "./lyric-line";

/**
 * 歌词行鼠标相关事件，可以获取到歌词行的索引和歌词行元素
 */
export class LyricLineMouseEvent extends MouseEvent {
	constructor(
		/**
		 * 歌词行索引
		 */
		public readonly lineIndex: number,
		/**
		 * 歌词行元素
		 */
		public readonly line: LyricLineEl,
		event: MouseEvent,
	) {
		super(`line-${event.type}`, event);
	}
}

export type LyricLineMouseEventListener = (evt: LyricLineMouseEvent) => void;

/**
 * 歌词播放组件，本框架的核心组件
 *
 * 尽可能贴切 Apple Music for iPad 的歌词效果设计，且做了力所能及的优化措施
 */
export class DomLyricPlayer extends LyricPlayerBase {
	override currentLyricLineObjects: LyricLineEl[] = [];
	readonly rowLayer = document.createElement("div");
	private browseColumn?: BrowseColumn;
	private timingEdges: number[] = [];
	private nextEdge = -Infinity;
	readonly clockMasks = new Set<LyricLineEl>();
	readonly movingLines = new Set<LyricLineEl>();

	protected override measureLineSizes() {
		// One forced layout per batch; release temporary glyphs before the next batch.
		const rows = this.currentLyricLineObjects;
		for (let i = 0; i < rows.length; i += 24) {
			const batch = rows.slice(i, i + 24);
			try {
				for (const line of batch) line.prepareMeasure();
				for (const line of batch) this.lyricLinesSize.set(line, line.readSize());
			} finally {
				for (const line of batch) line.finishMeasure();
			}
		}
	}

	override beginBrowse() {
		if (!this.currentLyricLineObjects.length || !super.beginBrowse()) return false;
		if (!this.browseColumn) {
			this.browseColumn = new BrowseColumn(this.rowLayer);
			this.nextEdge = -Infinity;
			this.calcLayout();
		}
		return true;
	}

	override queueBrowseLayout(force = true) {
		// Scroll input only changes the offset. update() presents its latest
		// value once per frame, even when many wheel events arrive together.
		if (!this.browseColumn) super.queueBrowseLayout(force);
	}

	setBrowseOffset(offset: number) {
		if (!this.beginBrowse()) return;
		this.scrollOffset = offset;
		this.limitScrollOffset();
	}

	revealLine(line: LyricLineEl) {
		if (!this.beginBrowse()) return;
		const column = this.browseColumn!;
		column.move(this.scrollOffset, this.size[1]);
		const index = this.lyricLinesIndexes.get(line);
		if (index === undefined) return;
		this.scrollOffset += column.screenTop(index) + line.lineSize[1] / 2 - this.size[1] * this.alignPosition;
		this.limitScrollOffset();
		column.move(this.scrollOffset, this.size[1]);
	}

	override resetScroll() {
		this.browseColumn?.finish();
		this.browseColumn = undefined;
		super.resetScroll();
	}

	override calcLayout(force?: boolean, reflow?: boolean) {
		const column = this.browseColumn;
		if (!column) return super.calcLayout(force, reflow);
		if (!this.size[0] || !this.size[1]) return;
		const center = this.size[1] * this.alignPosition;
		const pendingDelta = this.scrollOffset - column.presentedOffset;
		let anchor = column.anchor(center);
		if (!anchor) {
			// A wheel gesture can start while auto-follow is still in flight.
			let nearest = Infinity;
			for (const line of this.currentLyricLineObjects) {
				if (line.getLine().isBG || line.getElement().parentElement !== this.rowLayer) continue;
				const y = line.lineTransforms.posY.getCurrentPosition();
				const distance = Math.abs(y + line.lineSize[1] / 2 - center);
				if (distance < nearest) { nearest = distance; anchor = { line, y }; }
			}
		}
		const rows: BrowseRow[] = [];
		super.calcLayout(true, reflow, (index, top, height, scale, opacity) => {
			const line = this.currentLyricLineObjects[index];
			rows.push({ line, top, height, scale, opacity });
			if (anchor?.line === line) this.scrollOffset = top - anchor.y;
		});
		column.setRows(rows, this.scrollOffset);
		if (anchor) this.scrollOffset += pendingDelta;
		this.limitScrollOffset();
	}

	override setCurrentTime(time: number, seek = false) {
		if (!seek && this.currentTime <= time && time < this.nextEdge) {
			this.lastCurrentTime = this.currentTime = time;
			return;
		}
		const rewound = time < this.currentTime;
		super.setCurrentTime(time, seek);
		if (rewound) {
			for (const line of this.currentLyricLineObjects) line.resetUnstartedInk(time);
		}
		this.browseColumn?.updateReadingState(time);
		const next = firstIndex(this.timingEdges.length, i => this.timingEdges[i] > time);
		this.nextEdge = this.timingEdges[next] ?? Infinity;
	}

	onResize(): void {
		const width = this.element.clientWidth, height = this.element.clientHeight;
		if (!width || !height) return;
		const styles = getComputedStyle(this.element);
		this._baseFontSize = Number.parseFloat(styles.fontSize);
		this.size[0] = this.innerSize[0] = width - parseFloat(styles.paddingLeft) - parseFloat(styles.paddingRight);
		this.size[1] = this.innerSize[1] = height - parseFloat(styles.paddingTop) - parseFloat(styles.paddingBottom);
		this.rebuildStyle();
		this.calcLayout(true, true);
		for (const line of this.currentLyricLineObjects) line.markMaskImageDirty();
	}

	readonly supportPlusLighter = CSS.supports("mix-blend-mode", "plus-lighter");
	readonly supportMaskImage = CSS.supports("mask-image", "none");
	readonly supportWebkitMaskImage = CSS.supports("-webkit-mask-image", "none");
	readonly innerSize: [number, number] = [0, 0];
	private readonly onLineClickedHandler = (e: RawLyricLineMouseEvent) => {
		const evt = new LyricLineMouseEvent(
			this.lyricLinesIndexes.get(e.line) ?? -1,
			e.line,
			e,
		);
		if (!this.dispatchEvent(evt)) {
			e.preventDefault();
			e.stopPropagation();
			e.stopImmediatePropagation();
		}
	};
	/**
	 * 是否为非逐词歌词
	 * @internal
	 */
	_getIsNonDynamic() {
		return this.isNonDynamic;
	}
	private _baseFontSize = Number.parseFloat(
		getComputedStyle(this.element).fontSize,
	);
	public get baseFontSize() {
		return this._baseFontSize;
	}
	constructor() {
		super();
		this.rowLayer.className = "anp-lyric-column";
		this.rowLayer.append(this.interludeDots.getElement(), this.bottomLine.getElement());
		this.element.append(this.rowLayer);
		this.onResize();
		this.element.classList.add("amll-lyric-player", "apple-now-playing-extspotify", "dom");
		if (this.disableSpring) {
			this.element.classList.add(styles.disableSpring);
		}
	}

	private rebuildStyle() {
		const width = this.innerSize[0];
		const height = this.innerSize[1];
		this.element.style.setProperty("--amll-lp-width", `${width.toFixed(4)}px`);
		this.element.style.setProperty(
			"--amll-lp-height",
			`${height.toFixed(4)}px`,
		);
	}

	override setWordFadeWidth(value = 0.5) {
		super.setWordFadeWidth(value);
		for (const el of this.currentLyricLineObjects) {
			el.markMaskImageDirty();
		}
	}

	/**
	 * 设置当前播放歌词，要注意传入后这个数组内的信息不得修改，否则会发生错误
	 * @param lines 歌词数组
	 * @param initialTime 初始时间，默认为 0
	 */
	override setLyricLines(lines: LyricLine[], initialTime = 0) {
		super.setLyricLines(lines, initialTime);
		this.movingLines.clear();
		this.clockMasks.clear();
		this.nextEdge = -Infinity;
		this.timingEdges = this.processedLines.flatMap(line => [line.startTime, line.endTime]).sort((a,b) => a-b);

		for (const line of this.currentLyricLineObjects) {
			line.removeMouseEventListener("click", this.onLineClickedHandler);
			line.removeMouseEventListener("contextmenu", this.onLineClickedHandler);
			line.dispose();
		}

		// 创建新的歌词行元素
		this.currentLyricLineObjects = this.processedLines.map((line, i) => {
			const lineEl = new LyricLineEl(this, line);
			lineEl.addMouseEventListener("click", this.onLineClickedHandler);
			lineEl.addMouseEventListener("contextmenu", this.onLineClickedHandler);
			// Rows are attached on first measurement or when they enter the viewport.
			this.lyricLinesIndexes.set(lineEl, i);
			lineEl.markMaskImageDirty();
			return lineEl;
		});

		this.setLinePosXSpringParams({});
		this.setLinePosYSpringParams({});
		this.setLineScaleSpringParams({});
		this.setCurrentTime(initialTime, true);
		this.calcLayout(true, true);
	}

	override pause() {
		super.pause();
		this.interludeDots.pause();
		for (const line of this.currentLyricLineObjects) {
			line.pause();
		}
	}

	override resume() {
		super.resume();
		this.interludeDots.resume();
		for (const line of this.currentLyricLineObjects) {
			line.resume();
		}
	}

	override update(delta = 0) {
		if (this.browseColumn) {
			if (!this.isPageVisible) return;
			this.browseColumn.move(this.scrollOffset, this.size[1]);
			for (const i of this.hotLines) this.currentLyricLineObjects[i]?.refreshBrowseInk();
			this.interludeDots.update(0, this.currentTime);
			for (const line of this.clockMasks) line.paintClockMasks(this.currentTime);
			return;
		}
		super.update(delta);
		if (!this.isPageVisible) return;
		const deltaS = delta / 1000;
		this.bottomLine.update(deltaS);
		const spring = this.getEnableSpring();
		for (const line of spring ? this.movingLines : this.currentLyricLineObjects) {
			line.update(deltaS);
			if (spring && line.motionSettled) this.movingLines.delete(line);
		}
		for (const line of this.clockMasks) line.paintClockMasks(this.currentTime);
	}

	override dispose(): void {
		super.dispose();
		this.element.remove();
		for (const el of this.currentLyricLineObjects) {
			el.dispose();
		}
		this.currentLyricLineObjects = [];
		this.movingLines.clear();
		this.clockMasks.clear();
		this.bottomLine.dispose();
		this.interludeDots.dispose();
	}
}
