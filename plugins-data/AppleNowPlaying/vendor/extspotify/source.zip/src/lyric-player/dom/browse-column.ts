import type { LyricLineEl } from "./lyric-line";

export interface BrowseRow {
	line: LyricLineEl;
	top: number;
	height: number;
	scale: number;
	opacity: number;
}

// First index satisfying a monotone predicate (or length).
export function firstIndex(length: number, matches: (i: number) => boolean) {
	let low = 0, high = length;
	while (low < high) {
		const mid = (low + high) >>> 1;
		if (matches(mid)) high = mid;
		else low = mid + 1;
	}
	return low;
}

export class BrowseColumn {
	private rows: BrowseRow[] = [];
	private all: BrowseRow[] = [];
	private mounted = new Map<LyricLineEl, { y: number; scale: number; opacity: number } | null>();
	private first = -1;
	private end = -1;
	private offset = NaN;
	private layoutOffset = 0;
	private origin = 0;

	constructor(private layer: HTMLElement) {
		layer.classList.add("anp-browsing-column");
	}

	anchor(y: number) {
		if (!this.rows.length || !Number.isFinite(this.offset)) return;
		const index = firstIndex(this.rows.length, i => this.rows[i].top + this.rows[i].height > y + this.offset);
		const row = this.rows[Math.min(index, this.rows.length - 1)];
		return { line: row.line, y: row.top - this.offset };
	}

	get presentedOffset() {
		return Number.isFinite(this.offset) ? this.offset : this.layoutOffset;
	}

	setRows(all: BrowseRow[], offset: number) {
		if (!this.all.length) {
			for (const row of all) {
				if (row.line.getElement().parentElement === this.layer) this.mounted.set(row.line, null);
			}
		}
		if (Number.isFinite(this.offset)) {
			this.origin += offset - this.offset;
			this.offset = offset;
		}
		this.layoutOffset = offset;
		this.all = all;
		this.rows = all.filter(row => row.height > 0);
		this.first = this.end = -1;
	}

	screenTop(index: number) {
		return this.all[index].top - (Number.isFinite(this.offset) ? this.offset : 0);
	}

	move(offset: number, height: number) {
		if (this.first >= 0 && offset === this.offset) return;
		const rows = this.rows;
		const first = firstIndex(rows.length, i => rows[i].top + rows[i].height > offset - 1);
		const end = firstIndex(rows.length, i => rows[i].top >= offset + height + 1);
		if (first !== this.first || end !== this.end) {
			const visible = rows.slice(first, end);
			const retained = new Set(visible.map(row => row.line));
			if (!Number.isFinite(this.offset) || !visible.some(row => this.mounted.has(row.line))) {
				this.origin = rows[first]?.top ?? 0;
			}
			for (const line of this.mounted.keys()) {
				if (retained.has(line)) continue;
				line.leaveBrowseWindow();
				this.mounted.delete(line);
			}
			for (const row of visible) {
				const y = row.top - this.origin, previous = this.mounted.get(row.line);
				if (previous && Math.abs(previous.y-y) < .001 && previous.scale === row.scale && previous.opacity === row.opacity) continue;
				row.line.placeInBrowse(y, row.scale, row.opacity);
				this.mounted.set(row.line, { y, scale: row.scale, opacity: row.opacity });
			}
			this.first = first;
			this.end = end;
		}
		this.offset = offset;
		this.layer.style.transform = `translate3d(0,${this.origin - offset}px,0)`;
	}

	updateReadingState(time: number) {
		for (const line of this.mounted.keys()) line.updateReadingState(time);
	}

	finish() {
		// Seed the original springs with the screen positions from the last
		// presented browse frame before removing the shared translation.
		if (Number.isFinite(this.offset)) {
			for (const row of this.all) row.line.lineTransforms.posY.setPosition(row.top - this.offset);
			for (const line of this.mounted.keys()) line.show();
		}
		this.layer.style.removeProperty("transform");
		this.layer.classList.remove("anp-browsing-column");
	}
}

